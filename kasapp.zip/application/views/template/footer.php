
	<footer id="footer" style="margin-top: 20px;">
		<p>&copy <?=date('Y');?> - KasApp | Dibuat oleh <a>M. Alif Ridwan Hanafi</a></p>
    </footer>
</div>
<script src="<?=base_url('assets/vendor/jquery/dist/jquery.min.js');?>"></script>
<script src="<?=base_url('assets/vendor/propper.js/dist/umd/popper.min.js');?>"></script>
<script src="<?=base_url('assets/vendor/bootstrap/dist/js/bootstrap.min.js');?>"></script>
<script src="<?=base_url('assets/js/custom.js');?>"></script>
</body>
</html>